//异步加载头部和底部
$("#header").load("header.php");
$("#footer").load("footer.php");

