<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<!-- 页面最底部-->
    <div class="footer-container">
        <div class="footer-wrap">
            <a href="#"><span class="fa fa-weibo"></span></a>
            <a href="#"><span class="fa fa-qq"></span></a>
            <a href="#"><span class="fa fa-tencent-weibo"></span></a>
            <a href="#"><span class="fa fa-weixin"></span></a>
        </div>
        <div class="footer-link">
            <a href="#">企业合作</a>
            <a href="#">人才招聘</a>
            <a href="#">联系我们</a>
            <a href="#">讲师招募</a>
            <a href="#">常见问题</a>
            <a href="#">意见反馈</a>
            <a href="#">友情链接</a>
        </div>
        <div class="footer-copyright">
            <p>©&nbsp;2017&nbsp;study.com&nbsp;京ICP备&nbsp;*******号-*</p>
        </div>
    </div>